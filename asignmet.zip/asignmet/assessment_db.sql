-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 02, 2019 at 09:27 AM
-- Server version: 5.7.27-0ubuntu0.16.04.1
-- PHP Version: 7.0.33-0ubuntu0.16.04.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `assessment_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `sex` int(11) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `name`, `email`, `phone`, `dob`, `sex`, `created_at`, `updated_at`) VALUES
(1, '1', 'Jhon', '1', '1', '2019-10-02', 0, '2019-10-02', NULL),
(2, '1', 'Sonarika', '1', '1', '2019-10-02', 0, '2019-10-02', NULL),
(3, '1', 'Vishal Sahu', '1', '1', '2019-10-02', 0, '2019-10-02', NULL),
(5, '1', 'Vijay', '1', '1', '2019-10-02', 0, '2019-10-02', NULL),
(6, '1', 'Jiten singh', '1', '1', '2019-10-02', 0, '2019-10-02', NULL),
(7, '1', 'Rahul singh', '1', '1', '2019-10-02', 0, '2019-10-02', NULL),
(8, '1', 'Shreya', '1', '1', '2019-10-02', 0, '2019-10-02', NULL),
(10, '1', 'Rohit singh', '1', '1', '2019-10-02', 0, '2019-10-02', NULL),
(11, '1', 'Abhilash ', '1', '1', '2019-10-02', 0, '2019-10-02', NULL),
(12, '1', 'Abhishek', '1', '1', '2019-10-02', 0, '2019-10-02', NULL),
(13, '1', 'Aditya', '1', '1', '2019-10-02', 0, '2019-10-02', NULL),
(14, '1', 'Ajay singh', '1', '1', '2019-10-02', 0, '2019-10-02', NULL),
(15, 'Jhon', 'Akhilesh', 'Jhon@gmail.com', '9782254', '2013-10-02', 0, '2019-10-02', NULL),
(17, 'Ramesh', 'Deepak', 'ramesh@gmail', '7254555', '2019-10-02', 0, '2019-10-02', NULL),
(18, 'Yuvaraj', 'Ganesh', 'yuvaraj@gmail.com', '6788888', '2019-10-02', 0, '2019-10-02', NULL),
(19, '1', 'Gaurav', '1', '1', '2019-10-02', 0, '2019-10-02', NULL),
(20, '1', 'Gautam', '1', '1', '2019-10-02', 0, '2019-10-02', NULL),
(21, '1', 'Kuldeep', '1', '1', '2019-10-02', 0, '2019-10-02', NULL),
(22, '1', 'Mukesh', '1', '1', '2019-10-02', 0, '2019-10-02', NULL),
(25, '1', NULL, '1', '1', '2019-10-02', 0, '2019-10-02', NULL),
(26, '1', NULL, '1', '1', '2019-10-02', 0, '2019-10-02', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
